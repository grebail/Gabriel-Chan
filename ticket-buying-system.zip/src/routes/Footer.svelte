<script>
	import { Footer, FooterCopyright, FooterIcon } from 'flowbite-svelte';
</script>

<Footer footerType="socialmedia" class="mx-auto max-w-7xl">
	<div class="sm:flex sm:items-center sm:justify-between">
		<FooterCopyright href="/" by="TicketHub" />
	</div>
</Footer>
